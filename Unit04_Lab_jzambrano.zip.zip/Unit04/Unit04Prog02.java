// Comments: 
/**
 * Class: CIST 2372 Java II
 * Quarter: Fall 2016
 * Instructor: Dave Busse
 * Description: Unit04 Lab Solution
 * Due: 10/9/2016
 * @author Jean Zambrano
 * @version 1.0
 *
 * By turning in this code, I Pledge:
 *  1. That I have completed the programming assignment independently.
 *  2. I have not copied the code from a student or any source.
 *  3. I have not given my code to any student.
 *
 */

// Set up the imports
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.util.Scanner;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

//
//Our class declaration
//
public class Unit04Prog02 {

	// Create the main method
   public static void main(String[] args) throws Exception {

	// Create a file
   java.io.File file = new java.io.File("CreateData.dat");
   //java.io.PrintWriter output = new java.io.PrintWriter(file);
   ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(file));
   
   // Create a for loop to write 100 random numbers
      for (int i = 0; i <= 99; i++) {
         int randNum = (int)(Math.random() * 100);
         output.writeInt(randNum);
      }
      
      // Close the program
      output.close();
   }
}