// Comments:
/**
 * Class: CIST 2372 Java II
 * Quarter: Fall 2016
 * Instructor: Dave Busse
 * Description: Unit04 Lab Solution
 * Due: 10/9/2016
 * @author Jean Zambrano
 * @version 1.0
 *
 * By turning in this code, I Pledge:
 *  1. That I have completed the programming assignment independently.
 *  2. I have not copied the code from a student or any source.
 *  3. I have not given my code to any student.
 *
 */

// Set up the imports
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.util.Scanner;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

//
// Our class declaration
//
public class Unit04Prog01 {

   // Create the main method
   public static void main(String[] args) throws Exception {
   
   // Prompt the user to enter file name 
   java.io.File file = new java.io.File("scores.txt");
   String fileName = JOptionPane.showInputDialog(null, "Please enter the file name:  ");
   Scanner input = new Scanner(file);   
     
   // Set up an if statement that compares the name prompted to the one in store.
   if(fileName.equals("scores.txt")) {  
      int total = 0;
      int count;
      while(input.hasNextInt()) {
         count = input.nextInt();
         total = total + count;
      }
      System.out.println("Total is: " + total);
   }
   
   // If the name is different than the one expected, then show error message.
   else {
      String message = "Sorry, file " + fileName + " not found";    
      JOptionPane.showMessageDialog(null, message, "ERROR", JOptionPane.ERROR_MESSAGE);
   }
   
   // Finish the program
   System.exit(0);
   }   
}