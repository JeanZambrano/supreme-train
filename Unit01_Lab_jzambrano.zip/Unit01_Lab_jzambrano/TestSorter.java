/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author JeanCarloZambrano
 */
import java.util.Collections;
import java.util.Scanner;

public class TestSorter {
  public static void main(String[] args) {
  
  java.util.ArrayList<String> arrayList = new java.util.ArrayList<>();
  String password = "end";
  Scanner scanner = new Scanner(System.in);
  
  while(true) {
  
  System.out.print("Write a word:");
  String string = scanner.nextLine();
  
   if(string.equals(password)) {
   System.out.print(arrayList);
   return;
  }
  else {
   arrayList.add(string);
  }
  
   System.out.println(" The word you chose is: " + string + " ");
   System.out.println(arrayList);
  }
 }
}