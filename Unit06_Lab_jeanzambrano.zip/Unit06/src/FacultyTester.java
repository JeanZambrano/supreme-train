/**
 * Class: CIST 2372 Java II
 * Quarter: Fall 2016
 * Instructor: Dave Busse
 * Description: Unit06 Lab Solution
 * Due: 11/13/2016
 * @author Jean Zambrano
 * @version 1.0
 *
 * By turning in this code, I Pledge:
 *  1. That I have completed the programming assignment independently.
 *  2. I have not copied the code from a student or any source.
 *  3. I have not given my code to any student.
 *
 */

// Declare imports
import java.sql.*;

// Declare FacultyTester class
public class FacultyTester {
	
	// Main method
	public static void main(String[] args) {
		Faculty faculty01 = new Faculty("111221110", "Duke", 'L', "Omar", "4445556666", "duke@city.com", "Marketing", "1999-04-05", "Manager", 5000.00, "13005");
		faculty01.setSocial("111221110");
		faculty01.setFirstName("Duke");
		faculty01.setMidName('L');
		faculty01.setLastName("Omar");
		faculty01.setPhoneNumber("4445556666");
		faculty01.setEmailAddress("duke@city.com");
		faculty01.setOfficeId("Marketing");
		faculty01.setStarttime("1999-04-05");
		faculty01.setPosition("Manager");
		faculty01.setPay(5000.00);
		faculty01.setDepartmentId("13005");
		
		// Try / catch block
		try {
			// Load the JDBC driver 
			Class.forName("com.mysql.jdbc.Driver");
			// Establish a connection 
			Connection connection = DriverManager.getConnection
					("jdbc:mysql://localhost/javabook?autoReconnect=true&useSSL=false", "scott", "tiger");
			Statement statement = connection.createStatement();
			resultSet resultSet02 = statement.executeQuery("select * from faculty where ssn = '111221110'");

			while (resultSet02.next())
				System.out.println(resultSet02.getString(1) + "\t" + resultSet02.getString(2) + "\t" + resultSet02.getString +
					"\t" + resultSet02.getString(3) + "\t" + resultSet02.getString(4) + "\t" + resultSet02.getString(5) 
					+ "\t" + resultSet02.getString(6) + "\t" + resultSet02.getString(7) + "\t" + resultSet02.getString(8) 
					+ "\t" + resultSet02.getString(9) + "\t" + resultSet02.getString(10)); 
			
				connection.close();
			} catch (Exception ex) {
				ex.printStackTrace();
		
		}
	}
}
