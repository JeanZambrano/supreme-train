/**
 * Class: CIST 2372 Java II
 * Quarter: Fall 2016
 * Instructor: Dave Busse
 * Description: Unit06 Lab Solution
 * Due: 11/13/2016
 * @author Jean Zambrano
 * @version 1.0
 *
 * By turning in this code, I Pledge:
 *  1. That I have completed the programming assignment independently.
 *  2. I have not copied the code from a student or any source.
 *  3. I have not given my code to any student.
 *
 */

// Declare imports
import java.sql.*;

// Declare GettingStartedDB class
public class GettingStartedDB {

	// Main method
	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		
		// Try / catch block
		try{
			// Load the JDBC driver 
			Class.forName("com.mysql.jdbc.Driver");
			// Establish a connection 
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/javabook?autoReconnect=true&useSSL=false", "scott", "tiger");
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery("select ssn, firstname, lastname, phone from faculty");
			while (resultSet.next())
				System.out.println(resultSet.getString(1) + "\t" + resultSet.getString(2) + "\t" + resultSet.getString(3));
			connection.close();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
	}
}
