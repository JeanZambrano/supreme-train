/**
 * Class: CIST 2372 Java II
 * Quarter: Fall 2016
 * Instructor: Dave Busse
 * Description: Unit06 Lab Solution
 * Due: 11/13/2016
 * @author Jean Zambrano
 * @version 1.0
 *
 * By turning in this code, I Pledge:
 *  1. That I have completed the programming assignment independently.
 *  2. I have not copied the code from a student or any source.
 *  3. I have not given my code to any student.
 *
 */

// Set up imports
import java.sql.*;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

// Create class
public class Faculty {
	private String social, firstname, lastname, phoneNumber, emailAddress, officeId, startime, position, departmentId;
	private char midName;
	private double pay;
}

// Faculty() method
public Faculty() {
	
	// Declare variables
	public Faculty(String ssn, String firstName, char mi, String lastName, String phone, String ewmail, String office,
			String startTime, String rank, double salary, String deptId) {
		social = ssn;
		firstName = firstName;
		midName = mi;
		lastName = lastName;
		phoneNumber = phone;
		emailAddress = email;
		officeId = office;
		startTime = startTime;
		position = rank;
		pay = salary;
		departmentId = deptId;
		
		
		// Try block
		try {
			// Load the JDBC driver 
			Class.forName("com.mysql.jdbc.Driver");
			// Establish a connection 
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/javabook?autoReconnect=true&useSSL=false", "scott", "tiger");
         // Create a statement
			Statement statement = connection.createStatement();
         // Inster into Faculty
			statement.executeUpdate("insert into faculty values('111221189', 'Molly', 'D', 'Davids', '4445556666', "
					+ "'mollyd@mail.com', 'Accounts', '2005-12-07', 'Trainer', 8000.00, '13321')");
			// Close the connection
			connection.close();
         // Catch block
			} catch (Exception ex) {
				ex.printStackTrace();
			}
}
			
// Faculty() method
public Faculty(String social) {
   // Try block
	try {
      // Load the JDBC driver 
		Class.forName("com.mysql.jdbc.Driver");
      // Establish a connection 
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/javabook?autoReconnect=true&useSSL=false", "scott", "tiger");
      // Create a statement
		Statement statement = connection.createStatement();
      // Select everything from Faculty where ssn = social
		ResultSet resultSet = statement.executeQuery("select * from Faculty where ssn = social");
		while (resultSet.next())
			System.out.println(resultSet.getString("ssn") + "\t" + resultSet.getString("firstName") + "\t" + resultSet.getString +
				"\t" + resultSet.getString("lastName") + "\t" + resultSet.getString("phone") + "\t" + resultSet.getString("email") 
				+ "\t" + resultSet.getString("office") + "\t" resultSet.getString("startTime") + "\t" + resultSet.getString("rank") 
				+ "\t" + resultSet.getString("salary") + "\t" + resultSet.getString("deptId")); 
      // Close the connection
		connection.close();
      // Catch block
		} catch (Exception ex) {
			ex.printStackTrace();
		}
}

// DeleteDB() method
public static void deleteDB(String social) {
	try {
		Class.forName("com.mysql.jdbc.Driver");
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/javabook?autoReconnect=true&useSSL=fa")
		Statement statement = connection.createStatement();
		statement.executeUpdate("delete * from Faculty where ssn = 'social'");
		connection.close();
	} catch (Exception ex) {
		ex.printStackTrace();
	}
}
		
	
		// Generate getters and setters

		public String getSocial() {
			return social;
		}
		public void setSocial(String social) {
			this.social = social;
		}
		public String getFirstName() {
			return FirstName;
		}
		public void setFirstName(String firstName) {
			FirstName = firstName;
		}
		public String getLastName() {
			return LastName;
		}
		public void setLastName(String lastName) {
			LastName = lastName;
		}
		public String getPhoneNumber() {
			return PhoneNumber;
		}
		public void setPhoneNumber(String phoneNumber) {
			PhoneNumber = phoneNumber;
		}
		public String getEmailAddress() {
			return EmailAddress;
		}
		public void setEmailAddress(String emailAddress) {
			EmailAddress = emailAddress;
		}
		public String getOfficeId() {
			return officeId;
		}
		public void setOfficeId(String officeId) {
			this.officeId = officeId;
		}
		public String getStarttime() {
			return Starttime;
		}
		public void setStarttime(String starttime) {
			Starttime = starttime;
		}
		public String getPosition() {
			return Position;
		}
		public void setPosition(String position) {
			Position = position;
		}
		public String getDepartmentId() {
			return DepartmentId;
		}
		public void setDepartmentId(String departmentId) {
			DepartmentId = departmentId;
		}
		public String getMidName() {
			return midName;
		}
		public void setMidName(String midName) {
			this.midName = midName;
		}
		public String getFirstname() {
			return firstname;
		}
		public void setFirstname(String firstname) {
			this.firstname = firstname;
		}
		public String getLastname() {
			return lastname;
		}
		public void setLastname(String lastname) {
			this.lastname = lastname;
		}
		public String getStartime() {
			return startime;
		}
		public void setStartime(String startime) {
			this.startime = startime;
		}
		public double getPay() {
			return pay;
		}
		public void setPay(double pay) {
			this.pay = pay;
		}
		public void setMidName(char midName) {
			this.midName = midName;
		}	
}
